#!/system/bin/sh
# danmu_api_server core manager
#
# Features:
# - Switch danmu_api core from GitHub repo/ref (download zipball)
# - Toggle autostart flag (no polling)
# - Query status (for the companion Manager App)
#
# SECURITY NOTICE:
# Switching core means downloading and running third-party code (Node.js) as root.
# Only use trusted repositories.

set -u

MODID="danmu_api_server"
MODDIR="/data/adb/modules/$MODID"
PERSIST="/data/adb/danmu_api_server"
CORE_DIR="$PERSIST/core"
TMP_DIR="$PERSIST/tmp"
LOGDIR="$PERSIST/logs"
LOGFILE="$LOGDIR/core_manager.log"

CTRL="$MODDIR/scripts/danmu_control.sh"
PIDFILE="$PERSIST/danmu_api.pid"
FLAG_AUTOSTART_NEW="$PERSIST/autostart.disabled"
FLAG_AUTOSTART_OLD="$PERSIST/service.disabled"  # legacy (<= v1.x)

mkdir -p "$PERSIST" "$CORE_DIR" "$TMP_DIR" "$LOGDIR" 2>/dev/null

# Prefer module-bundled tools if present
BB="$MODDIR/bin/busybox"
if [ -x "$BB" ]; then
  export PATH="$MODDIR/bin:$PATH"
  export LD_LIBRARY_PATH="$MODDIR/bin/lib:${LD_LIBRARY_PATH:-}"
fi
# Some Termux binaries may rely on libs shipped with the module
if [ -d "$MODDIR/node/lib" ]; then
  export LD_LIBRARY_PATH="$MODDIR/node/lib:${LD_LIBRARY_PATH:-}"
fi

log() {
  echo "[danmu_api][core] $(date '+%F %T') $*" >> "$LOGFILE" 2>/dev/null
}

normalize_repo() {
  r="$1"
  r="${r#https://github.com/}"
  r="${r#http://github.com/}"
  r="${r%/}"
  r="${r%.git}"
  echo "$r"
}

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

download_file() {
  url="$1"
  out="$2"

  rm -f "$out" 2>/dev/null

  if have_cmd curl; then
    curl -fL --retry 3 --connect-timeout 10 --max-time 600 "$url" -o "$out" && return 0
  fi

  if have_cmd wget; then
    wget -O "$out" "$url" && return 0
  fi

  if have_cmd toybox; then
    if toybox wget --help >/dev/null 2>&1; then
      toybox wget -O "$out" "$url" && return 0
    fi
  fi

  if [ -x "$BB" ]; then
    if "$BB" wget --help >/dev/null 2>&1; then
      "$BB" wget -O "$out" "$url" && return 0
    fi
  fi

  return 1
}

unzip_to() {
  zipf="$1"
  outdir="$2"

  rm -rf "$outdir" 2>/dev/null
  mkdir -p "$outdir" 2>/dev/null

  if have_cmd unzip; then
    unzip -q "$zipf" -d "$outdir" && return 0
  fi

  if have_cmd toybox; then
    if toybox unzip --help >/dev/null 2>&1; then
      toybox unzip -q "$zipf" -d "$outdir" && return 0
    fi
  fi

  if [ -x "$BB" ]; then
    if "$BB" unzip --help >/dev/null 2>&1; then
      "$BB" unzip -q "$zipf" -d "$outdir" && return 0
    fi
  fi

  return 1
}

is_running() {
  if [ -f "$PIDFILE" ]; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
    if [ -n "${pid:-}" ] && kill -0 "$pid" 2>/dev/null; then
      return 0
    fi
  fi
  return 1
}

autostart_status() {
  # Migrate legacy flag (<= v1.x)
  if [ -f "$FLAG_AUTOSTART_OLD" ] && [ ! -f "$FLAG_AUTOSTART_NEW" ]; then
    mv -f "$FLAG_AUTOSTART_OLD" "$FLAG_AUTOSTART_NEW" 2>/dev/null || true
  fi

  if [ -f "$FLAG_AUTOSTART_NEW" ] || [ -f "$FLAG_AUTOSTART_OLD" ]; then
    echo "off"
  else
    echo "on"
  fi
}

print_core_source() {
  if [ -f "$CORE_DIR/.core_source" ]; then
    cat "$CORE_DIR/.core_source" 2>/dev/null
    return 0
  fi
  echo "repo=unknown"
  echo "ref=unknown"
  return 0
}

cmd="${1:-}"

case "$cmd" in
  status)
    if is_running; then
      echo "service=running"
    else
      echo "service=stopped"
    fi
    echo "autostart=$(autostart_status)"
    print_core_source
    ;;

  autostart)
    sub="${2:-status}"
    case "$sub" in
      status)
        echo "autostart=$(autostart_status)"
        ;;
      on)
        rm -f "$FLAG_AUTOSTART_NEW" "$FLAG_AUTOSTART_OLD" 2>/dev/null
        echo "autostart=on"
        ;;
      off)
        # Turn off autostart (does NOT affect current running state)
        touch "$FLAG_AUTOSTART_NEW" 2>/dev/null
        rm -f "$FLAG_AUTOSTART_OLD" 2>/dev/null
        echo "autostart=off"
        ;;
      *)
        echo "Usage: $0 autostart {on|off|status}"
        exit 2
        ;;
    esac
    ;;

  install)
    repo_raw="${2:-}"
    ref="${3:-}"
    if [ -z "$repo_raw" ] || [ -z "$ref" ]; then
      echo "Usage: $0 install <owner/repo> <ref>"
      exit 2
    fi

    repo="$(normalize_repo "$repo_raw")"

    # Basic sanity
    case "$repo" in
      */*) : ;;
      *)
        echo "Invalid repo format: $repo (expected owner/repo)"
        exit 2
        ;;
    esac

    if [ ! -d "$MODDIR" ]; then
      echo "Module dir not found: $MODDIR"
      exit 1
    fi

    url="https://codeload.github.com/${repo}/zip/${ref}"
    zipf="$TMP_DIR/core.zip"
    exdir="$TMP_DIR/extract"

    log "install begin: repo=$repo ref=$ref"

    running_before=0
    if is_running; then
      running_before=1
    fi

    # Stop service before switching core (avoid partial reads)
    if [ -x "$CTRL" ]; then
      "$CTRL" stop >/dev/null 2>&1 || true
    fi

    echo "download_url=$url"

    if ! download_file "$url" "$zipf"; then
      log "download failed: $url"
      echo "error=download_failed"
      exit 1
    fi

    if ! unzip_to "$zipf" "$exdir"; then
      log "unzip failed: $zipf"
      echo "error=unzip_failed"
      exit 1
    fi

    worker_path="$(find "$exdir" -type f -name worker.js 2>/dev/null | grep '/danmu_api/worker.js$' | head -n 1 || true)"
    if [ -z "$worker_path" ]; then
      log "worker.js not found in extracted zip"
      echo "error=core_not_found"
      exit 1
    fi

    src_dir="$(dirname "$worker_path")"
    if [ ! -f "$src_dir/worker.js" ]; then
      log "invalid core dir: $src_dir"
      echo "error=invalid_core"
      exit 1
    fi

    # Backup current core (single backup)
    rm -rf "$PERSIST/core.bak" 2>/dev/null
    if [ -d "$CORE_DIR" ]; then
      mv "$CORE_DIR" "$PERSIST/core.bak" 2>/dev/null || true
    fi

    mkdir -p "$CORE_DIR" 2>/dev/null
    cp -a "$src_dir/." "$CORE_DIR/" 2>/dev/null || true

    if [ ! -f "$CORE_DIR/worker.js" ]; then
      log "core copy failed; restoring backup"
      rm -rf "$CORE_DIR" 2>/dev/null
      if [ -d "$PERSIST/core.bak" ]; then
        mv "$PERSIST/core.bak" "$CORE_DIR" 2>/dev/null || true
      fi
      echo "error=copy_failed"
      exit 1
    fi

    # Save source info
    {
      echo "repo=$repo"
      echo "ref=$ref"
      echo "updated_at=$(date '+%F %T')"
    } > "$CORE_DIR/.core_source" 2>/dev/null || true

    # Ensure module core path is a symlink to persistent core
    rm -rf "$MODDIR/app/danmu_api" 2>/dev/null
    ln -s "$CORE_DIR" "$MODDIR/app/danmu_api" 2>/dev/null

    # Cleanup temp
    rm -f "$zipf" 2>/dev/null
    rm -rf "$exdir" 2>/dev/null

    log "install ok: repo=$repo ref=$ref"

    echo "result=ok"

    # Restart service if it was running before
    if [ "$running_before" -eq 1 ] && [ -x "$CTRL" ]; then
      "$CTRL" start >/dev/null 2>&1 || true
    fi

    ;;

  *)
    echo "Usage: $0 {status|autostart|install}"
    echo "  $0 status"
    echo "  $0 autostart {on|off|status}"
    echo "  $0 install <owner/repo> <branch|tag|commit>"
    exit 2
    ;;
esac
