#!/system/bin/sh
# Global watchdog installed into /data/adb/service.d
# It starts/stops danmu_api_server when the module is enabled/disabled in Magisk.
set -u

MODID="danmu_api_server"
MODDIR="/data/adb/modules/$MODID"
PERSIST="/data/adb/danmu_api_server"
LOGFILE="$PERSIST/logs/watchdog.log"
CTRL="$MODDIR/scripts/danmu_control.sh"

mkdir -p "$PERSIST/logs" 2>/dev/null

now() { date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "date"; }
log() { echo "[$(now)] $*" >> "$LOGFILE" 2>/dev/null; }

# Prevent multiple watchdogs
WDPID="$PERSIST/watchdog.pid"
if [ -f "$WDPID" ]; then
  old="$(cat "$WDPID" 2>/dev/null || true)"
  if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
    exit 0
  fi
fi
echo $$ > "$WDPID" 2>/dev/null

# Wait for boot completion
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
  sleep 2
done
sleep 2

module_enabled() {
  [ -d "$MODDIR" ] || return 1
  [ -f "$MODDIR/disable" ] && return 1
  [ -f "$MODDIR/remove" ] && return 1
  return 0
}

stop_fallback() {
  PIDFILE="$PERSIST/danmu_api.pid"
  if [ -f "$PIDFILE" ]; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null || true
    rm -f "$PIDFILE" 2>/dev/null || true
  fi
}

last=""
log "[danmu_api] watchdog started"
while true; do
  if module_enabled; then
    state="enabled"
  else
    state="disabled"
  fi

  if [ "$state" != "$last" ]; then
    log "[danmu_api] state change: ${last:-none} -> $state"
    if [ "$state" = "enabled" ]; then
      if [ -x "$CTRL" ]; then
        sh "$CTRL" start
      else
        log "[danmu_api] controller missing, cannot start"
      fi
    else
      if [ -x "$CTRL" ]; then
        sh "$CTRL" stop
      else
        stop_fallback
        log "[danmu_api] stopped (fallback)"
      fi
    fi
    last="$state"
  fi

  # Keep-alive when enabled: if crashed, restart
  if [ "$state" = "enabled" ] && [ -x "$CTRL" ]; then
    sh "$CTRL" status >/dev/null 2>&1 || sh "$CTRL" start
  fi

  sleep 2
done
