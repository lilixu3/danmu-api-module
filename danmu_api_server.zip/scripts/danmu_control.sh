#!/system/bin/sh
# Danmu API Server controller
# Usage: danmu_control.sh {start|stop|restart|status}
set -u

MODDIR="$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)"
MODID="danmu_api_server"

# Persistent root
PERSIST="/data/adb/danmu_api_server"

# New runtime root (config is stored at runtime/config to match upstream UI/NodeHandler path)
RUNTIME="$PERSIST/app"
CONFIG_DIR="$RUNTIME/config"

PIDFILE="$PERSIST/danmu_api.pid"
LOGFILE="$PERSIST/logs/service.log"
VERSION_FILE="$PERSIST/.runtime_version"

mkdir -p "$PERSIST/logs" 2>/dev/null

now() { date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "date"; }
log() { echo "[$(now)] $*" >> "$LOGFILE" 2>/dev/null; }

find_node() {
  # Prefer common node locations (Termux / system)
  for b in /data/data/com.termux/files/usr/bin/node /system/bin/node /system/xbin/node /sbin/node /su/bin/node; do
    [ -x "$b" ] && echo "$b" && return 0
  done
  command -v node 2>/dev/null || return 1
}

ensure_runtime() {
  # Make sure runtime exists and is synced at least once.
  [ -f "$RUNTIME/android-server.mjs" ] && return 0

  # Try to trigger the same sync logic used at boot (post-fs-data)
  if [ -x "$MODDIR/post-fs-data.sh" ]; then
    sh "$MODDIR/post-fs-data.sh" >/dev/null 2>&1 || true
  fi

  [ -f "$RUNTIME/android-server.mjs" ] && return 0

  # Fallback: run directly from module app (not persistent) if runtime is missing
  return 1
}

is_running() {
  [ -f "$PIDFILE" ] || return 1
  pid="$(cat "$PIDFILE" 2>/dev/null || true)"
  [ -n "$pid" ] || return 1
  kill -0 "$pid" 2>/dev/null
}

stop_service() {
  if is_running; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
    [ -n "$pid" ] && kill -15 "$pid" 2>/dev/null || true
    sleep 1
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null || true
    rm -f "$PIDFILE" 2>/dev/null || true
    log "[danmu_api] stopped (pid=$pid)"
  else
    # try kill by cmdline fallback
    pids="$(ps -A 2>/dev/null | grep -E 'android-server\.mjs' | grep -v grep | awk '{print $2}' 2>/dev/null || true)"
    for p in $pids; do
      [ -n "$p" ] && kill -0 "$p" 2>/dev/null && kill -9 "$p" 2>/dev/null || true
    done
    rm -f "$PIDFILE" 2>/dev/null || true
    log "[danmu_api] stopped"
  fi
}

start_service() {
  if is_running; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
    log "[danmu_api] already running (pid=$pid)"
    return 0
  fi

  nodebin="$(find_node 2>/dev/null)" || {
    log "[danmu_api] Node.js not found. Please install Node.js (e.g. Termux: pkg install nodejs-lts) and reboot."
    return 0
  }

  appdir="$RUNTIME"
  if ensure_runtime; then
    appdir="$RUNTIME"
  else
    appdir="$MODDIR/app"
    mkdir -p "$appdir/config" 2>/dev/null || true
    log "[danmu_api] WARNING: runtime not prepared, falling back to module app (config may not persist across module updates)."
  fi

  cd "$appdir" 2>/dev/null || return 0

  # IMPORTANT:
  # Upstream danmu_api (UI/NodeHandler) reads/writes config under app/config
  export DANMU_API_HOME="$appdir"
  export NODE_ENV="${NODE_ENV:-production}"

  log "[danmu_api] starting with node: $nodebin (appdir=$appdir)"
  nohup "$nodebin" "$appdir/android-server.mjs" >> "$LOGFILE" 2>&1 &
  echo $! > "$PIDFILE" 2>/dev/null
  sleep 1

  if is_running; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
    log "[danmu_api] started (pid=$pid)"
    return 0
  else
    log "[danmu_api] failed to start"
    rm -f "$PIDFILE" 2>/dev/null || true
    return 1
  fi
}

case "${1:-}" in
  start)   start_service ;;
  stop)    stop_service ;;
  restart) stop_service; start_service ;;
  status)
    if is_running; then
      echo "running (pid=$(cat "$PIDFILE" 2>/dev/null || true))"
      exit 0
    else
      echo "stopped"
      exit 1
    fi
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status}" >&2
    exit 2
    ;;
esac
