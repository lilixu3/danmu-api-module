#!/system/bin/sh
# Danmu API Server controller
# Usage: danmu_control.sh {start|stop|restart|status}
set -u

MODDIR="$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)"
MODID="danmu_api_server"
PERSIST="/data/adb/danmu_api_server"
PIDFILE="$PERSIST/danmu_api.pid"
LOGFILE="$PERSIST/logs/service.log"

mkdir -p "$PERSIST/logs" 2>/dev/null

now() { date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "date"; }
log() { echo "[$(now)] $*" >> "$LOGFILE" 2>/dev/null; }

find_node() {
  # 1) user override
  if [ -n "${DANMU_API_NODE:-}" ] && [ -x "$DANMU_API_NODE" ]; then
    echo "$DANMU_API_NODE"; return 0
  fi
  # 2) common locations
  for p in         /data/data/com.termux/files/usr/bin/node         /data/data/com.termux/files/usr/bin/nodejs         /data/adb/modules/nodejs/system/bin/node         /system/bin/node         /system/xbin/node         /vendor/bin/node
  do
    if [ -x "$p" ]; then
      echo "$p"; return 0
    fi
  done
  # 3) PATH
  if command -v node >/dev/null 2>&1; then
    p="$(command -v node 2>/dev/null)"
    if [ -n "$p" ] && [ -x "$p" ]; then
      echo "$p"; return 0
    fi
  fi
  return 1
}

is_running() {
  if [ -f "$PIDFILE" ]; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
      return 0
    fi
  fi
  return 1
}

find_pids_by_cmd() {
  pat="$1"
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -f "$pat" 2>/dev/null || true
    return 0
  fi
  # Fallback to ps+grep
  psout="$(ps -A 2>/dev/null || ps 2>/dev/null || true)"
  echo "$psout" | grep "$pat" | grep -v grep | awk '{print $2}' 2>/dev/null || true
}

stop_service() {
  pid=""
  if [ -f "$PIDFILE" ]; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
  fi

  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    log "[danmu_api] stopping (pid=$pid)"
    kill "$pid" 2>/dev/null || true
    # wait up to 5s then SIGKILL
    i=0
    while [ $i -lt 5 ]; do
      kill -0 "$pid" 2>/dev/null || break
      sleep 1
      i=$((i+1))
    done
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null || true
  fi

  # Best-effort cleanup of stray processes
  for p in $(find_pids_by_cmd "$MODDIR/app/android-server.mjs"); do
    [ -n "$p" ] && kill -0 "$p" 2>/dev/null && kill -9 "$p" 2>/dev/null || true
  done

  rm -f "$PIDFILE" 2>/dev/null || true
  log "[danmu_api] stopped"
}

start_service() {
  if is_running; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
    log "[danmu_api] already running (pid=$pid)"
    return 0
  fi

  nodebin="$(find_node 2>/dev/null)" || {
    log "[danmu_api] Node.js not found. Please install Node.js (e.g. Termux: pkg install nodejs-lts) and reboot."
    return 0
  }

  cd "$MODDIR/app" 2>/dev/null || return 0

  export DANMU_API_HOME="$PERSIST"
  export NODE_ENV="${NODE_ENV:-production}"

  log "[danmu_api] starting with node: $nodebin"
  nohup "$nodebin" "$MODDIR/app/android-server.mjs" >> "$LOGFILE" 2>&1 &
  echo $! > "$PIDFILE" 2>/dev/null
  sleep 1

  if is_running; then
    log "[danmu_api] started (pid=$(cat "$PIDFILE" 2>/dev/null || true))"
  else
    log "[danmu_api] start failed (check logs above)"
  fi
}

case "${1:-}" in
  start) start_service ;;
  stop) stop_service ;;
  restart) stop_service; start_service ;;
  status)
    if is_running; then
      echo "running (pid=$(cat "$PIDFILE" 2>/dev/null || true))"
      exit 0
    else
      echo "stopped"
      exit 1
    fi
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status}" >&2
    exit 2
    ;;
esac
