#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
  sleep 5
done
sleep 2

# Start service (controller prevents duplicates)
sh "$MODDIR/scripts/danmu_control.sh" start
