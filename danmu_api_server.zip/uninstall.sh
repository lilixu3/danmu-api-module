#!/system/bin/sh
MODID="danmu_api_server"
MODDIR="/data/adb/modules/$MODID"
PERSIST="/data/adb/danmu_api_server"
LOGFILE="$PERSIST/logs/service.log"

# Stop server
if [ -x "$MODDIR/scripts/danmu_control.sh" ]; then
  sh "$MODDIR/scripts/danmu_control.sh" stop
else
  PIDFILE="$PERSIST/danmu_api.pid"
  if [ -f "$PIDFILE" ]; then
    pid="$(cat "$PIDFILE" 2>/dev/null || true)"
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null || true
    rm -f "$PIDFILE" 2>/dev/null || true
  fi
fi

# Remove watchdog installed in service.d
rm -f "/data/adb/service.d/$MODID-watchdog.sh" 2>/dev/null || true
rm -f "$PERSIST/watchdog.pid" 2>/dev/null || true

echo "[danmu_api] Module removed. Persistent data kept in $PERSIST (delete manually if you want)." >> "$LOGFILE" 2>/dev/null
