#!/system/bin/sh
# This script is sourced by Magisk's module installer (if present).

MODID="danmu_api_server"
SERVICE_D="/data/adb/service.d"

# Permissions
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/scripts/danmu_control.sh" 0 0 0755
set_perm "$MODPATH/scripts/danmu_watchdog.sh" 0 0 0755

# Install watchdog so enabling/disabling the module in Magisk will start/stop the service without reboot
mkdir -p "$SERVICE_D" 2>/dev/null
rm -f "$SERVICE_D/$MODID-watchdog.sh" 2>/dev/null
cp -f "$MODPATH/scripts/danmu_watchdog.sh" "$SERVICE_D/$MODID-watchdog.sh" 2>/dev/null
set_perm "$SERVICE_D/$MODID-watchdog.sh" 0 0 0755
