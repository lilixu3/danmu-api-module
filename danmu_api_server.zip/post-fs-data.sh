#!/system/bin/sh
MODDIR=${0%/*}
PERSIST=/data/adb/danmu_api_server

# Runtime layout (no symlink needed):
#   $PERSIST/app            -> Node runtime root (copied from module on install/update)
#   $PERSIST/app/config     -> Config directory expected by upstream danmu_api (UI/NodeHandler uses app/config)
#   $PERSIST/logs           -> Logs, pid, etc.
RUNTIME="$PERSIST/app"
CONFIG_DIR="$RUNTIME/config"
LOGS_DIR="$PERSIST/logs"
LEGACY_CONFIG_DIR="$PERSIST/config"
VERSION_FILE="$PERSIST/.runtime_version"

cp_safe() {
  # Prefer archive mode (preserve perms/times) if supported; fallback gracefully.
  cp -af "$@" 2>/dev/null || cp -rf "$@" 2>/dev/null
}

# Create persistent dirs
mkdir -p "$CONFIG_DIR" "$LOGS_DIR" 2>/dev/null

# Migrate legacy config dir ($PERSIST/config -> $PERSIST/app/config) if present
if [ -d "$LEGACY_CONFIG_DIR" ]; then
  if [ -f "$LEGACY_CONFIG_DIR/.env" ] && [ ! -f "$CONFIG_DIR/.env" ]; then
    cp_safe "$LEGACY_CONFIG_DIR/.env" "$CONFIG_DIR/.env"
  fi
  if [ -f "$LEGACY_CONFIG_DIR/config.yaml" ] && [ ! -f "$CONFIG_DIR/config.yaml" ]; then
    cp_safe "$LEGACY_CONFIG_DIR/config.yaml" "$CONFIG_DIR/config.yaml"
  fi
fi

# Install default config if missing
if [ ! -f "$CONFIG_DIR/.env" ]; then
  cp_safe "$MODDIR/defaults/config/.env" "$CONFIG_DIR/.env"
fi
if [ ! -f "$CONFIG_DIR/config.yaml" ]; then
  cp_safe "$MODDIR/defaults/config/config.yaml" "$CONFIG_DIR/config.yaml"
fi

# Sync runtime app files from module -> persistent runtime (preserve config/)
MODULE_APP="$MODDIR/app"
CUR_VER="$(grep -m1 '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
[ -z "$CUR_VER" ] && CUR_VER="0"

need_sync=0
if [ ! -f "$RUNTIME/android-server.mjs" ]; then
  need_sync=1
elif [ ! -f "$VERSION_FILE" ]; then
  need_sync=1
else
  last_ver="$(cat "$VERSION_FILE" 2>/dev/null || echo 0)"
  [ "$last_ver" != "$CUR_VER" ] && need_sync=1
fi

if [ "$need_sync" = "1" ] && [ -d "$MODULE_APP" ]; then
  # Remove old runtime files except config/
  if [ -d "$RUNTIME" ]; then
    for p in "$RUNTIME"/*; do
      [ -e "$p" ] || continue
      [ "$(basename "$p")" = "config" ] && continue
      rm -rf "$p" 2>/dev/null
    done
  else
    mkdir -p "$RUNTIME" 2>/dev/null
  fi

  # Copy module app -> runtime (exclude config/)
  for p in "$MODULE_APP"/*; do
    [ -e "$p" ] || continue
    [ "$(basename "$p")" = "config" ] && continue
    cp_safe "$p" "$RUNTIME/"
  done

  echo "$CUR_VER" > "$VERSION_FILE" 2>/dev/null
fi

# Permissions (protect secrets)
chmod 600 "$CONFIG_DIR/.env" 2>/dev/null
chmod 644 "$CONFIG_DIR/config.yaml" 2>/dev/null
chmod 755 "$PERSIST" "$RUNTIME" "$CONFIG_DIR" "$LOGS_DIR" 2>/dev/null
