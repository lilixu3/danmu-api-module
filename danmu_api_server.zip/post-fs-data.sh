#!/system/bin/sh
MODDIR=${0%/*}
PERSIST=/data/adb/danmu_api_server

# Create persistent dirs
mkdir -p "$PERSIST/config" "$PERSIST/logs" 2>/dev/null

# Install default config if missing
if [ ! -f "$PERSIST/config/.env" ]; then
  cp -f "$MODDIR/defaults/config/.env" "$PERSIST/config/.env" 2>/dev/null
fi
if [ ! -f "$PERSIST/config/config.yaml" ]; then
  cp -f "$MODDIR/defaults/config/config.yaml" "$PERSIST/config/config.yaml" 2>/dev/null
fi

# Protect secrets in .env
chmod 600 "$PERSIST/config/.env" 2>/dev/null
chmod 644 "$PERSIST/config/config.yaml" 2>/dev/null
chmod 755 "$PERSIST" "$PERSIST/config" "$PERSIST/logs" 2>/dev/null
# Symlink module-local config to persistent config so UI save always writes to persistent config
# Node handler writes to: $MODDIR/app/config/.env and config.yaml
if [ -d "$MODDIR/app" ]; then
  rm -rf "$MODDIR/app/config" 2>/dev/null
  ln -s "$PERSIST/config" "$MODDIR/app/config" 2>/dev/null
fi
