package com.danmuapi.manager.root

import com.danmuapi.manager.data.model.CoreListResponse
import com.danmuapi.manager.data.model.LogFileInfo
import com.danmuapi.manager.data.model.LogsResponse
import com.danmuapi.manager.data.model.StatusResponse
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class DanmuCli {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val statusAdapter = moshi.adapter(StatusResponse::class.java)
    private val coreListAdapter = moshi.adapter(CoreListResponse::class.java)
    private val logsAdapter = moshi.adapter(LogsResponse::class.java)

    private fun extractJsonObject(text: String): String? {
        val s = text.trim()
        val start = s.indexOf('{')
        val end = s.lastIndexOf('}')
        if (start >= 0 && end > start) return s.substring(start, end + 1)
        return null
    }

    private fun <T> parseJsonSafely(adapter: JsonAdapter<T>, raw: String): T? {
        val direct = raw.trim()
        if (direct.isNotBlank()) {
            try {
                adapter.fromJson(direct)?.let { return it }
            } catch (_: Throwable) {
                // fall through
            }
        }

        val extracted = extractJsonObject(raw) ?: return null
        return try {
            adapter.fromJson(extracted)
        } catch (_: Throwable) {
            null
        }
    }

    suspend fun getStatus(): StatusResponse? {
        val cmd = "${DanmuPaths.CORE_CLI} status --json"
        val res = RootShell.runSu(cmd)
        if (res.exitCode != 0) return null
        return parseJsonSafely(statusAdapter, res.stdout)
    }

    suspend fun listCores(): CoreListResponse? {
        val cmd = "${DanmuPaths.CORE_CLI} core list --json"
        val res = RootShell.runSu(cmd)
        if (res.exitCode != 0) return null
        return parseJsonSafely(coreListAdapter, res.stdout)
    }

    suspend fun startService(): Boolean {
        val res = RootShell.runSu("${DanmuPaths.CONTROL_CLI} start")
        return res.exitCode == 0
    }

    suspend fun stopService(): Boolean {
        val res = RootShell.runSu("${DanmuPaths.CONTROL_CLI} stop")
        return res.exitCode == 0
    }

    suspend fun restartService(): Boolean {
        val res = RootShell.runSu("${DanmuPaths.CONTROL_CLI} restart")
        return res.exitCode == 0
    }

    suspend fun setAutostart(enabled: Boolean): Boolean {
        val sub = if (enabled) "on" else "off"
        val res = RootShell.runSu("${DanmuPaths.CORE_CLI} autostart $sub")
        return res.exitCode == 0
    }

    suspend fun installCore(repo: String, ref: String): Boolean {
        val safeRepo = repo.replace("\"", "")
        val safeRef = ref.replace("\"", "")
        val res = RootShell.runSu("${DanmuPaths.CORE_CLI} core install '$safeRepo' '$safeRef'")
        return res.exitCode == 0
    }

    suspend fun activateCore(id: String): Boolean {
        val safeId = id.replace("\"", "")
        val res = RootShell.runSu("${DanmuPaths.CORE_CLI} core activate '$safeId'")
        return res.exitCode == 0
    }

    suspend fun deleteCore(id: String): Boolean {
        val safeId = id.replace("\"", "")
        val res = RootShell.runSu("${DanmuPaths.CORE_CLI} core delete '$safeId'")
        return res.exitCode == 0
    }

    suspend fun listLogs(): LogsResponse? {
        // Primary: ask the module CLI for JSON.
        // Note: keep compatibility with older scripts that do NOT support "--json" for logs.
        val res = RootShell.runSu("${DanmuPaths.CORE_CLI} logs list", timeoutMs = 10_000)
        if (res.exitCode == 0) {
            val parsed = parseJsonSafely(logsAdapter, res.stdout)
            if (parsed != null) return parsed
        }

        // Fallback: manual scan of the log directory.
        // Some devices/ROMs may have issues with JSON parsing if su adds extra output,
        // or if the CLI script is temporarily unavailable.
        val logDir = DanmuPaths.LOG_DIR
        val cmd = buildString {
            append("for f in '")
            append(logDir)
            append("'/*; do ")
            append("[ -f \"\$f\" ] || continue; ")
            append("name=\"\$(basename \"\$f\")\"; ")
            append("size=\"\$(wc -c < \"\$f\" 2>/dev/null || echo 0)\"; ")
            append("mtime=\"\$(date -r \"\$f\" '+%F %T' 2>/dev/null || echo '')\"; ")
            append("printf '%s\t%s\t%s\t%s\n' \"\$name\" \"\$f\" \"\$size\" \"\$mtime\"; ")
            append("done")
        }
        val r2 = RootShell.runSu(cmd, timeoutMs = 10_000)

        val files = r2.stdout
            .split('\n')
            .mapNotNull { line ->
                val t = line.trimEnd()
                if (t.isBlank()) return@mapNotNull null
                val parts = t.split('\t')
                if (parts.size < 2) return@mapNotNull null
                val name = parts.getOrNull(0).orEmpty()
                val path = parts.getOrNull(1).orEmpty()
                val size = parts.getOrNull(2)?.toLongOrNull() ?: 0L
                val mtime = parts.getOrNull(3)?.takeIf { it.isNotBlank() }
                LogFileInfo(
                    name = name,
                    path = path,
                    sizeBytes = size,
                    modifiedAt = mtime,
                )
            }

        return LogsResponse(dir = logDir, files = files)
    }

    suspend fun clearLogs(): Boolean {
        val res = RootShell.runSu("${DanmuPaths.CORE_CLI} logs clear")
        return res.exitCode == 0
    }

    suspend fun tailLog(path: String, lines: Int = 200): String? {
        val safePath = path
            .replace("\"", "")
            .replace("'", "")
            .trim()
            .replace("\r", "")
            .replace("\n", "")

        if (safePath.isBlank()) return null

        val n = lines.coerceIn(10, 2000)
        val busybox = "${DanmuPaths.BIN_DIR}/busybox"

        // Keep the command single-line for maximum su compatibility.
        val cmd = "p='$safePath'; n=$n; " +
            "if [ ! -f \"\$p\" ]; then echo \"file not found: \$p\" 1>&2; exit 2; fi; " +
            "if [ -x '$busybox' ]; then '$busybox' tail -n \$n \"\$p\"; " +
            "elif command -v toybox >/dev/null 2>&1; then toybox tail -n \$n \"\$p\"; " +
            "elif command -v tail >/dev/null 2>&1; then tail -n \$n \"\$p\"; " +
            "else cat \"\$p\"; fi"

        val res = RootShell.runSu(cmd, timeoutMs = 15_000)
        if (res.exitCode != 0 && res.stdout.isBlank()) {
            val err = res.stderr.trim().ifBlank { "exitCode=${res.exitCode}" }
            return "（读取失败：$err）"
        }
        return res.stdout
    }

    /**
     * Reads the persistent config file (.env).
     *
     * Note: returns empty string if file does not exist.
     */
    suspend fun readEnvFile(): String? {
        val f = DanmuPaths.ENV_FILE
        val cmd = "if [ -f '$f' ]; then cat '$f'; else echo -n ''; fi"
        val res = RootShell.runSu(cmd, timeoutMs = 10_000)
        if (res.exitCode != 0) return null
        return res.stdout
    }

    /**
     * Atomically writes the persistent config file (.env) with a timestamped backup.
     */
    suspend fun writeEnvFile(content: String): Boolean {
        val file = DanmuPaths.ENV_FILE
        val dir = file.substringBeforeLast('/')
        val ts = System.currentTimeMillis()
        val tmp = "$file.tmp.$ts"
        val bak = "$file.bak.$ts"
        val marker = "__DANMU_ENV_EOF__$ts"

        // Ensure the here-doc terminator is always on its own line.
        val safeContent = if (content.endsWith("\n")) content else "$content\n"

        val cmd = buildString {
            append("mkdir -p '")
            append(dir)
            append("' || exit 1\n")

            // Backup: best-effort (do not fail the write if backup fails).
            append("if [ -f '")
            append(file)
            append("' ]; then cp -f '")
            append(file)
            append("' '")
            append(bak)
            append("' 2>/dev/null || true; fi\n")

            // Write to tmp then move.
            append("cat <<'")
            append(marker)
            append("' > '")
            append(tmp)
            append("'\n")
            append(safeContent)
            append(marker)
            append("\n")
            append("chmod 600 '")
            append(tmp)
            append("' 2>/dev/null || true\n")
            append("mv -f '")
            append(tmp)
            append("' '")
            append(file)
            append("'\n")
        }

        val res = RootShell.runSu(cmd, timeoutMs = 15_000)
        return res.exitCode == 0
    }
}
