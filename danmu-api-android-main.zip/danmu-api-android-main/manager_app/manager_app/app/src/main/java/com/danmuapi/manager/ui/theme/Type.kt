package com.danmuapi.manager.ui.theme

import androidx.compose.material3.Typography

// Keep typography close to stock Material3 for a clean "store-ready" look.
val Typography = Typography()
