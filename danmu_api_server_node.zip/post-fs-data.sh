#!/system/bin/sh
MODDIR=${0%/*}

# Persistent runtime data (config/logs/runtime)
PERSIST=/data/adb/danmu_api_server
CFG_DIR="$PERSIST/config"
LOGDIR="$PERSIST/logs"

mkdir -p "$PERSIST" "$CFG_DIR" "$LOGDIR" 2>/dev/null

# Cleanup legacy bind-mount / module-internal config path (older versions)
OLD_MOD_CFG="/data/adb/modules/danmu_api_server/app/config"
umount -l "$OLD_MOD_CFG" 2>/dev/null || true
rm -rf "$OLD_MOD_CFG" 2>/dev/null

# Protect secrets
chmod 755 "$PERSIST" "$CFG_DIR" "$LOGDIR" 2>/dev/null
chmod 600 "$CFG_DIR/.env" 2>/dev/null
chmod 644 "$CFG_DIR/config.yaml" 2>/dev/null

exit 0
