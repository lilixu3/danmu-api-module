#!/system/bin/sh
MODDIR=${0%/*}

# Persistent runtime data (logs/pid/watchdog)
PERSIST=/data/adb/danmu_api_server

# UI/Env-API expects config files here (relative to app/danmu_api/*):
#   $MODDIR/app/config/.env
#   $MODDIR/app/config/config.yaml
UI_CFG_DIR="$MODDIR/app/config"

# Legacy config location (older module versions)
LEGACY_CFG_DIR="$PERSIST/config"

# Create dirs
mkdir -p "$PERSIST/logs" "$UI_CFG_DIR" 2>/dev/null

# If UI config dir is a symlink (old workaround), replace with a real directory
if [ -L "$UI_CFG_DIR" ]; then
  rm -f "$UI_CFG_DIR" 2>/dev/null
  mkdir -p "$UI_CFG_DIR" 2>/dev/null
fi

# Migrate legacy config -> UI config (only if UI config missing)
if [ ! -f "$UI_CFG_DIR/.env" ] && [ -f "$LEGACY_CFG_DIR/.env" ]; then
  cp -f "$LEGACY_CFG_DIR/.env" "$UI_CFG_DIR/.env" 2>/dev/null
fi
if [ ! -f "$UI_CFG_DIR/config.yaml" ] && [ -f "$LEGACY_CFG_DIR/config.yaml" ]; then
  cp -f "$LEGACY_CFG_DIR/config.yaml" "$UI_CFG_DIR/config.yaml" 2>/dev/null
fi

# Install defaults if still missing
if [ ! -f "$UI_CFG_DIR/.env" ]; then
  cp -f "$MODDIR/defaults/config/.env" "$UI_CFG_DIR/.env" 2>/dev/null
fi
if [ ! -f "$UI_CFG_DIR/config.yaml" ]; then
  cp -f "$MODDIR/defaults/config/config.yaml" "$UI_CFG_DIR/config.yaml" 2>/dev/null
fi

# Protect secrets in .env
chmod 600 "$UI_CFG_DIR/.env" 2>/dev/null
chmod 644 "$UI_CFG_DIR/config.yaml" 2>/dev/null
chmod 755 "$PERSIST" "$PERSIST/logs" "$MODDIR/app" "$UI_CFG_DIR" 2>/dev/null

# Cleanup obsolete (wrong) config link/dir from very old builds
if [ -e "$MODDIR/app/danmu_api/config" ] || [ -L "$MODDIR/app/danmu_api/config" ]; then
  rm -rf "$MODDIR/app/danmu_api/config" 2>/dev/null
fi

exit 0
