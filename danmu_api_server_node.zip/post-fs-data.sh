#!/system/bin/sh
MODDIR=${0%/*}

# Persistent runtime data (logs/pid/toggle/config)
PERSIST=/data/adb/danmu_api_server
PERSIST_CFG="$PERSIST/config"

# danmu_api/UI reads/writes config here. We'll bind-mount persistent config to this path.
UI_CFG_DIR="$MODDIR/app/config"

# Legacy config location (older module versions, keep compatibility if exists)
LEGACY_CFG_DIR="$PERSIST/config_legacy"

# Create dirs
mkdir -p "$PERSIST/logs" "$PERSIST_CFG" "$UI_CFG_DIR" 2>/dev/null

# If persistent config missing, try migrate from current module config (first boot after install)
if [ ! -f "$PERSIST_CFG/.env" ] && [ -f "$UI_CFG_DIR/.env" ]; then
  cp -f "$UI_CFG_DIR/.env" "$PERSIST_CFG/.env" 2>/dev/null
fi
if [ ! -f "$PERSIST_CFG/config.yaml" ] && [ -f "$UI_CFG_DIR/config.yaml" ]; then
  cp -f "$UI_CFG_DIR/config.yaml" "$PERSIST_CFG/config.yaml" 2>/dev/null
fi

# If still missing, seed from defaults
if [ ! -f "$PERSIST_CFG/.env" ] && [ -f "$MODDIR/defaults/config/.env" ]; then
  cp -f "$MODDIR/defaults/config/.env" "$PERSIST_CFG/.env" 2>/dev/null
fi
if [ ! -f "$PERSIST_CFG/config.yaml" ] && [ -f "$MODDIR/defaults/config/config.yaml" ]; then
  cp -f "$MODDIR/defaults/config/config.yaml" "$PERSIST_CFG/config.yaml" 2>/dev/null
fi

# Bind-mount persistent config to module path (no symlink; updates won't overwrite)
# Avoid repeated mounts
if ! grep -q " $UI_CFG_DIR " /proc/mounts 2>/dev/null; then
  umount -l "$UI_CFG_DIR" 2>/dev/null
  # Some Android builds support --bind, some require -o bind
  mount --bind "$PERSIST_CFG" "$UI_CFG_DIR" 2>/dev/null || mount -o bind "$PERSIST_CFG" "$UI_CFG_DIR" 2>/dev/null
fi

# Protect secrets in .env (on persistent dir)
chmod 600 "$PERSIST_CFG/.env" 2>/dev/null
chmod 644 "$PERSIST_CFG/config.yaml" 2>/dev/null
chmod 755 "$PERSIST" "$PERSIST/logs" "$PERSIST_CFG" "$MODDIR/app" "$UI_CFG_DIR" 2>/dev/null

# Cleanup obsolete (wrong) config link/dir from very old builds
if [ -e "$MODDIR/app/danmu_api/config" ] || [ -L "$MODDIR/app/danmu_api/config" ]; then
  rm -rf "$MODDIR/app/danmu_api/config" 2>/dev/null
fi

exit 0
