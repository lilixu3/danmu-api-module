#!/system/bin/sh
MODDIR=${0%/*}

# Persistent runtime data (config/logs/runtime)
PERSIST=/data/adb/danmu_api_server
CFG_DIR="$PERSIST/config"
LOGDIR="$PERSIST/logs"

mkdir -p "$PERSIST" "$CFG_DIR" "$LOGDIR" 2>/dev/null

# Ensure module config path points to persistent config (single source of truth)
# Web UI / env-api writes to: $MODDIR/app/config
# We keep it as a symlink to: $CFG_DIR
MOD_CFG="$MODDIR/app/config"
umount -l "$MOD_CFG" 2>/dev/null || true
rm -rf "$MOD_CFG" 2>/dev/null
ln -s "$CFG_DIR" "$MOD_CFG" 2>/dev/null

# Protect secrets
chmod 755 "$PERSIST" "$CFG_DIR" "$LOGDIR" 2>/dev/null
chmod 600 "$CFG_DIR/.env" 2>/dev/null
rm -f "$CFG_DIR/config.yaml" 2>/dev/null

exit 0
