\
#!/system/bin/sh
# Magisk-independent watchdog installed into /data/adb/service.d
# It reacts to Magisk enable/disable toggles without requiring reboot.
set -u

MODID="danmu_api_server"
MODULE_DIR="/data/adb/modules/$MODID"
CTRL="$MODULE_DIR/scripts/danmu_control.sh"

PERSIST="/data/adb/danmu_api_server"
LOGDIR="$PERSIST/logs"
WLOG="$LOGDIR/watchdog.log"
WPID="$PERSIST/watchdog.pid"

mkdir -p "$PERSIST" "$LOGDIR" 2>/dev/null
echo $$ > "$WPID" 2>/dev/null

log() {
  echo "[danmu_api][watchdog] $(date '+%F %T') $*" >> "$WLOG" 2>/dev/null
}

# Wait for boot completion once (service.d runs early on some devices)
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
  sleep 2
done
sleep 2

last_state=""

while true; do
  # If module folder is gone, stop and exit.
  if [ ! -d "$MODULE_DIR" ]; then
    if [ -x "$CTRL" ]; then
      "$CTRL" stop >/dev/null 2>&1
    fi
    log "module directory missing; exiting watchdog"
    rm -f "$WPID" 2>/dev/null || true
    exit 0
  fi

  # Magisk uses 'disable' marker file when user disables a module.
  if [ -f "$MODULE_DIR/disable" ]; then
    state="disabled"
  else
    state="enabled"
  fi

  if [ "$state" != "$last_state" ]; then
    log "state change: $last_state -> $state"
    last_state="$state"
  fi

  if [ "$state" = "disabled" ]; then
    if [ -x "$CTRL" ]; then
      "$CTRL" stop >/dev/null 2>&1
    fi
  else
    if [ -x "$CTRL" ]; then
      "$CTRL" start >/dev/null 2>&1
    fi
  fi

  sleep 2
done
