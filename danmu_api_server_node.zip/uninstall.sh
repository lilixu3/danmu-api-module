#!/system/bin/sh
MODID="danmu_api_server"
MODULE_DIR="/data/adb/modules/$MODID"
PERSIST="/data/adb/danmu_api_server"

CTRL="$MODULE_DIR/scripts/danmu_control.sh"

# Stop service
if [ -x "$CTRL" ]; then
  "$CTRL" stop >/dev/null 2>&1
fi

# Remove watchdog from service.d
rm -f /data/adb/service.d/danmu_api_server-watchdog.sh 2>/dev/null

# Cleanup watchdog pid file (logs/config kept as before)
rm -f "$PERSIST/watchdog.pid" 2>/dev/null

LOGFILE="$PERSIST/logs/service.log"
echo "[danmu_api] Module removed. Persistent data kept in $PERSIST (delete manually if you want)." >> "$LOGFILE" 2>/dev/null
