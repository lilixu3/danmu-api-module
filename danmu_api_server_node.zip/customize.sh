#!/system/bin/sh
# This script is sourced by Magisk's module installer.

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

# Magisk Action button
if [ -f "$MODPATH/action.sh" ]; then
  set_perm "$MODPATH/action.sh" 0 0 0755
fi

# Control + helper scripts
if [ -d "$MODPATH/scripts" ]; then
  set_perm_recursive "$MODPATH/scripts" 0 0 0755 0755
fi

# Node binary must be executable
if [ -f "$MODPATH/node/bin/node" ]; then
  set_perm "$MODPATH/node/bin/node" 0 0 0755
fi

# Persistent runtime/data directory
MODID="danmu_api_server"
PERSIST="/data/adb/danmu_api_server"
CFG_DIR="$PERSIST/config"
LOGDIR="$PERSIST/logs"

# Older versions stored config inside the module folder (and sometimes bind-mounted).
# We'll migrate once and then use ONLY $CFG_DIR as the single source of truth.
OLD_MOD_CFG="/data/adb/modules/$MODID/app/config"

# Ensure directories exist
mkdir -p "$PERSIST" "$CFG_DIR" "$LOGDIR" 2>/dev/null

# One-time migrate from previous installed module (if user曾经直接改过模块内配置)
# 目标：最终只保留一个配置文件：$CFG_DIR/.env
if [ ! -f "$CFG_DIR/.env" ] && [ -f "$OLD_MOD_CFG/.env" ]; then
  cp -f "$OLD_MOD_CFG/.env" "$CFG_DIR/.env" 2>/dev/null
fi

# 如果旧版只存在 config.yaml，则尽量转换为 .env（仅支持顶层 KEY: VALUE）
if [ ! -f "$CFG_DIR/.env" ] && [ -f "$OLD_MOD_CFG/config.yaml" ]; then
  awk '
    /^[[:space:]]*#/ {next}
    /^[[:space:]]*$/ {next}
    {
      if (match($0, /^[[:space:]]*([A-Za-z0-9_]+)[[:space:]]*:[[:space:]]*(.*)$/, a)) {
        key=a[1]; val=a[2];
        sub(/[[:space:]]+#.*$/, "", val);
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", val);
        if (val ~ /^\".*\"$/) { val=substr(val,2,length(val)-2); }
        print key "=" val;
      }
    }
  ' "$OLD_MOD_CFG/config.yaml" > "$CFG_DIR/.env" 2>/dev/null
fi

# If still missing, seed from defaults (do not overwrite user config)
if [ ! -f "$CFG_DIR/.env" ] && [ -f "$MODPATH/defaults/config/.env.example" ]; then
  cp -f "$MODPATH/defaults/config/.env.example" "$CFG_DIR/.env" 2>/dev/null
fi

# 强制只保留一个配置文件
rm -f "$CFG_DIR/config.yaml" 2>/dev/null

# permissions
chmod 755 "$PERSIST" "$CFG_DIR" "$LOGDIR" 2>/dev/null
chmod 600 "$CFG_DIR/.env" 2>/dev/null

# 清理旧版误复制到 $PERSIST 的运行时目录，避免本地文件重复占空间
rm -rf "$PERSIST/danmu_api" "$PERSIST/node_modules" \
       "$PERSIST/android-server.mjs" "$PERSIST/package.json" 2>/dev/null

# 让 Web UI / env-api 继续写 "app/config"，但实际落到持久化目录
# - app/config 作为软链接指向 $CFG_DIR
rm -rf "$MODPATH/app/config" 2>/dev/null
ln -s "$CFG_DIR" "$MODPATH/app/config" 2>/dev/null


# Install event-driven watcher into /data/adb/service.d (no polling)
SERVICE_D="/data/adb/service.d"
PERSIST="/data/adb/danmu_api_server"
mkdir -p "$SERVICE_D" 2>/dev/null

# Remove old polling watchdog if present
rm -f "$SERVICE_D/danmu_api_server-watchdog.sh" 2>/dev/null
rm -f "$PERSIST/watchdog.pid" 2>/dev/null

# Install inotifyd watcher (if device has inotifyd, module toggle will be instant)
cp -f "$MODPATH/scripts/danmu_inotifyd_service.sh" "$SERVICE_D/danmu_api_server-inotifyd.sh" 2>/dev/null
chmod 0755 "$SERVICE_D/danmu_api_server-inotifyd.sh" 2>/dev/null
