#!/system/bin/sh
# This script is sourced by Magisk's module installer.

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

# Magisk Action button
if [ -f "$MODPATH/action.sh" ]; then
  set_perm "$MODPATH/action.sh" 0 0 0755
fi

# Control + helper scripts
if [ -d "$MODPATH/scripts" ]; then
  set_perm_recursive "$MODPATH/scripts" 0 0 0755 0755
fi

# Node binary must be executable
if [ -f "$MODPATH/node/bin/node" ]; then
  set_perm "$MODPATH/node/bin/node" 0 0 0755
fi

# Prepare UI config directory inside module so the web UI can read/write immediately
CFG_DIR="$MODPATH/app/config"
mkdir -p "$CFG_DIR" 2>/dev/null
if [ ! -f "$CFG_DIR/.env" ] && [ -f "$MODPATH/defaults/config/.env" ]; then
  cp -f "$MODPATH/defaults/config/.env" "$CFG_DIR/.env" 2>/dev/null
fi
if [ ! -f "$CFG_DIR/config.yaml" ] && [ -f "$MODPATH/defaults/config/config.yaml" ]; then
  cp -f "$MODPATH/defaults/config/config.yaml" "$CFG_DIR/config.yaml" 2>/dev/null
fi
chmod 600 "$CFG_DIR/.env" 2>/dev/null
chmod 644 "$CFG_DIR/config.yaml" 2>/dev/null

# Install event-driven watcher into /data/adb/service.d (no polling)
SERVICE_D="/data/adb/service.d"
PERSIST="/data/adb/danmu_api_server"
mkdir -p "$SERVICE_D" 2>/dev/null

# Remove old polling watchdog if present
rm -f "$SERVICE_D/danmu_api_server-watchdog.sh" 2>/dev/null
rm -f "$PERSIST/watchdog.pid" 2>/dev/null

# Install inotifyd watcher (if device has inotifyd, module toggle will be instant)
cp -f "$MODPATH/scripts/danmu_inotifyd_service.sh" "$SERVICE_D/danmu_api_server-inotifyd.sh" 2>/dev/null
chmod 0755 "$SERVICE_D/danmu_api_server-inotifyd.sh" 2>/dev/null
