#!/system/bin/sh
MODDIR=${0%/*}

# Optional manual service toggle (Magisk Action button)
# If this flag exists, do not auto-start on boot.
PERSIST=/data/adb/danmu_api_server
# New flag name (separate "autostart" from manual start/stop)
FLAG_NEW="$PERSIST/autostart.disabled"
FLAG_OLD="$PERSIST/service.disabled"

# Migrate legacy flag (<= v1.x)
if [ -f "$FLAG_OLD" ] && [ ! -f "$FLAG_NEW" ]; then
  mv -f "$FLAG_OLD" "$FLAG_NEW" 2>/dev/null || true
fi

if [ -f "$FLAG_NEW" ] || [ -f "$FLAG_OLD" ]; then
  exit 0
fi

# Wait for boot completion (network + storage stable)
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
  sleep 5
done
sleep 5

# Magisk entrypoint: delegate to control script.
"$MODDIR/scripts/danmu_control.sh" start
