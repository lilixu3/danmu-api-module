#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion (network + storage stable)
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
  sleep 5
done
sleep 5

# Magisk entrypoint: delegate to control script.
"$MODDIR/scripts/danmu_control.sh" start
