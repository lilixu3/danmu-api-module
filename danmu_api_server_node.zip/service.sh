#!/system/bin/sh
MODDIR=${0%/*}

# Optional manual service toggle (Magisk Action button)
# If this flag exists, do not auto-start on boot.
PERSIST=/data/adb/danmu_api_server
if [ -f "$PERSIST/service.disabled" ]; then
  exit 0
fi

# Wait for boot completion (network + storage stable)
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ]; do
  sleep 5
done
sleep 5

# Magisk entrypoint: delegate to control script.
"$MODDIR/scripts/danmu_control.sh" start
